package ru.mirea.lab7;

import java.util.*;

class MyArrayList<T>
{
    private final int SIZE = 16;
    private final int CUT_RATE = 4;
    private Object[] array = new Object[SIZE];
    private int numberOfElements = 0;

    public void add(T item)
    {
        if (numberOfElements == array.length - 1) resize(array.length * 2);
        array[numberOfElements++] = item;
    }

    public T get(int index)
    {
        return (T) array[index];
    }

    public void remove(int index)
    {
        for (int i = index; i < numberOfElements; i++)
        {
            array[i] = array[i + 1];
        }
        array[numberOfElements] = null;
        numberOfElements--;
        if (array.length > SIZE && numberOfElements < array.length / CUT_RATE) resize(array.length / 2);
    }

    public int size()
    {
        return numberOfElements;
    }

    public int capacity()
    {
        return array.length;
    }

    private void resize(int newLength)
    {
        Object[] newArray = new Object[newLength];
        System.arraycopy(array, 0, newArray, 0, numberOfElements);
        array = newArray;
    }

    private void output(MyArrayList list)
    {
        for (int i = 0; i < list.size(); i++)
        {
            System.out.print(list.get(i) + " ");
        }
    }
}

public class Main
{
    public static void main(String[] args)
    {
        MyArrayList testArray = new MyArrayList();
        double rndNumber;
        for (int i = 0; i < 64; i++)
        {
            rndNumber = Math.random();
            testArray.add(rndNumber);
        }
        for (int i = 0; i < testArray.size(); i++)
        {
            System.out.println(testArray.get(i));
        }
        System.out.println(testArray.capacity());
        for (int i = 0; i < 50; i++)
        {
            testArray.remove(0);
        }
        for (int i = 0; i < testArray.size(); i++)
        {
            System.out.println(testArray.get(i));
        }
        System.out.println(testArray.capacity());
    }

}

