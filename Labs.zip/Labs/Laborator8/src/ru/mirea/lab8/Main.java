package ru.mirea.lab8;
import java.io.*;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        String str = "";
        Scanner scan = new Scanner(System.in);
        String line;
        line = scan.nextLine();
        // Запись введенной строки в файл
        try(FileWriter writer = new FileWriter("C:\\Users\\magmu\\Desktop\\Учеба\\ООП\\Лабы\\Laborator8\\text.txt", false))
        {
            writer.write((line + ' '));
            writer.flush();
        }
    catch(IOException ex){

        System.out.println(ex.getMessage());
    }
        // Считывание из файла строки
        try(FileReader reader = new FileReader("C:\\Users\\magmu\\Desktop\\Учеба\\ООП\\Лабы\\Laborator8\\text.txt"))
        {
            int c;
            while((c=reader.read())!=-1){

                System.out.print((char)c);
            }
            System.out.println(" ");
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }

        // Считывание файла для добавления записи в конец
        try(FileReader reader = new FileReader("C:\\Users\\magmu\\Desktop\\Учеба\\ООП\\Лабы\\Laborator8\\text.txt"))
        {
            int c;
            while((c=reader.read())!=-1){

                str += ((char)c);
            }
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }

        // Добавление записи в конец файла
        try(FileWriter writer = new FileWriter("C:\\Users\\magmu\\Desktop\\Учеба\\ООП\\Лабы\\Laborator8\\text.txt", false))
        {
            line = scan.nextLine();
            str += line += ' ';
            writer.write(str);
            writer.flush();
        }
        catch(IOException ex){

            System.out.println(ex.getMessage());
        }
        // Считывание из файла строки
        try(FileReader reader = new FileReader("C:\\Users\\magmu\\Desktop\\Учеба\\ООП\\Лабы\\Laborator8\\text.txt"))
        {
            int c;
            while((c=reader.read())!=-1){

                System.out.print((char)c);
            }
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }


    }
}
