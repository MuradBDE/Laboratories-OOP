package ru.mirea.lab2;


public class Main
{
    public static void main(String[] args)
    {
        Book book1;
        Book book2 = new Book();
        book1 = new Book(1973, "Сидоренко", "Книга том 1", "Москва");
        book2.setYear(1976);
        book2.setAuthor("Сидоров");
        book2.setName("Книга том 2");
        book2.setPublishingHouse("Москва");
        System.out.println("Информация о книге: " + book1.getName()+ ":\n" + "Автор: " + book1.getAuthor() + ". Издательство: " + book1.getPublishingHouse() + ". Год: " + book1.getYear());
        System.out.println(book2);
    }
}
