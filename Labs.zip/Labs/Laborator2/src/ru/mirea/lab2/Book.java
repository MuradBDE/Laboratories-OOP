package ru.mirea.lab2;

public class Book
{
    private int year;
    private String author;
    private String name;
    private String publishingHouse;

    Book(int _year, String _author, String _name, String _publishingHouse){
        year = _year;
        author = _author;
        name = _name;
        publishingHouse = _publishingHouse;
    }
    Book(){

    }

    public String getAuthor(){
        return author;
    }
    public String getName(){
        return name;
    }
    public String getPublishingHouse(){
        return publishingHouse;
    }
    public int getYear(){
        return year;
    }
    public void setAuthor(String _author){
        author = _author;
    }
    public void setName(String _name){
        name = _name;
    }
    public void setPublishingHouse(String _publishingHouse){
        publishingHouse = _publishingHouse;
    }
    public void setYear(int _year){
        year = _year;
    }
    public String toString(){
        return "Информация о книге: " + name+ ":\n" + "Автор: " + author + ". Издательство: " + publishingHouse + ". Год: " + year;
    }

}
