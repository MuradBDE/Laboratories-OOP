package ru.mirea.lab9;

public class Throws1 {
    public static class ThrowsDemo {
        public void getDetails(String key) {
            if (key == null) {
                throw new NullPointerException("null key in getDetails");
            }
            // do something with the key
        }
    }


    public static void main(String[] args) {
        ThrowsDemo temp = new ThrowsDemo();
        String nullString = null;
        try {
            temp.getDetails(nullString);
        } catch (NullPointerException e) {
            System.out.println("Exception caught");
        }
    }
}
