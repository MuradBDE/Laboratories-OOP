package ru.mirea.lab9;

public class Throws2 {
    public static class ThrowsDemo {
        public void printMessage(String key) {
            try {
                String message = getDetails(key);
                System.out.println(message);
            } catch (NullPointerException e) {
                System.out.println("Exception caught");
            }
        }

        public String getDetails(String key) {
            if (key == null) {
                throw new NullPointerException("null key in getDetails");
            }
            return "data for " + key;
        }
    }

    public static void main(String[] args) {
        ThrowsDemo temp = new ThrowsDemo();
        temp.printMessage(null);
        temp.printMessage("key");
    }
}
