package ru.mirea.lab6;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class mainForm extends JFrame
{
    int guesses = 3;
    JButton guessButton = new JButton("Ответ");
    Font font = new Font("Times new roman",Font.BOLD,18);
    JTextField guessTF = new JTextField(15);
    mainForm()
    {
        Random rnd = new Random();
        setLayout(new FlowLayout());
        setSize(350, 120);
        add(guessTF);
        add(guessButton);
        guessTF.setFont(font);
        setVisible(true);
        int number = rnd.nextInt(21);
        guessButton.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e)
            {
                if  (isNumber(guessTF.getText()))
                {
                    int temp = Integer.parseInt(guessTF.getText());
                    if  (temp == number)
                    {
                        JOptionPane.showMessageDialog(null, "Вы отгадали число! Игра окончена.");
                        System.exit(0);
                    }
                    else {
                        guesses--;
                        if (guesses > 0)
                        {
                            if (temp > number)
                                JOptionPane.showMessageDialog(null, "Введенное число больше загаданного. Осталось попыток: " + guesses);
                            else
                                JOptionPane.showMessageDialog(null, "Введенное число меньше загаданного. Осталось попыток: " + guesses);
                        }
                        else {
                            JOptionPane.showMessageDialog(null, "Введено неверное число. Загаданное число: " + number);
                            System.exit(0);
                        }
                    }

                }
                else JOptionPane.showMessageDialog(null, "Введите целое число от до 20");
            }
        });
    }
    boolean isNumber(String str) {
        if(str.length() > 2) return false;
        if(str.equals("")) return false;
        boolean answ = true;
        char[] tempArray = str.toCharArray();
        for(int i = 0; i < str.length(); i++)
        {
            if(!Character.isDigit(tempArray[i])) answ = false;
        }
        return answ;
    }

    public static void main(String[] args)
    {
        new mainForm();
    }
}
