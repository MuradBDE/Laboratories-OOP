package ru.mirea.lab10;

class superContainer
{
    private int length;
    private int lastElement = 0;
    private Object[] array;

    public superContainer(int size)
    {
        length = size;
        array = new Object[length];
    }
    public void add(Object object)
    {
        array[lastElement] = object;
        lastElement++;
    }
    public Object get(int index)
    {
        return array[index];
    }
    public int getLength(){
        return length;
    }
}

public class Exercise2 {
    public static void main(String[] args)
    {
        superContainer container = new superContainer(10);
        for (int i = 0; i < container.getLength(); i++)
        {
            container.add(i + 1);
            i++;
            container.add(i + 1 + " Элемент");
        }
        for (int i = 0; i < 10; i++)
        {
            System.out.println(container.get(i));
        }
    }
}
