package ru.mirea.lab10;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Exercise3 {
    public static List readFiles(File directory){
        List list = new ArrayList();
        int counter = 0;
        if (directory.isDirectory()){
            for (File file : directory.listFiles()) {
                if(!file.isFile() && counter < 5){
                    list.add(file);
                    counter++;
                    readFiles(file);
                }
            }
        }
        return list;
    }
    public static void main(String[] args)
    {
        List list = readFiles(new File("E:\\di\\Учеба\\ООП\\Лабы ООП\\Laborator10"));
        for(Object element: list){
            System.out.println(element);
        }
    }
}
