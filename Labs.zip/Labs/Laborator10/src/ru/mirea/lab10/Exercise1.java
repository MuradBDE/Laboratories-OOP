package ru.mirea.lab10;

import java.util.ArrayList;
import java.util.List;

public class Exercise1 {
    public static List arrayToList(Object[] array) {
        List arrayList = new ArrayList<>();
        for (int i = 0; i < array.length; i++)
        {
            arrayList.add(array[i]);
        }
        return arrayList;
    }
}
