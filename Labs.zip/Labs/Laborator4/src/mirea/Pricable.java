package mirea;

public interface Pricable
{
    void getPrice();
}
