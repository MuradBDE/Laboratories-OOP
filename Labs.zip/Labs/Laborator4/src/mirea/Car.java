package mirea;

public class Car implements Pricable
{
    Car(int _price, int _maxSpeed, String _name){
        price = _price;
        maxSpeed = _maxSpeed;
        name = _name;
    }
    private int price, maxSpeed;
    private String name;
    public void getPrice(){
        System.out.printf("Название машины: %s\nЦена: %d миллионов.\n", name, price);
    }
}
