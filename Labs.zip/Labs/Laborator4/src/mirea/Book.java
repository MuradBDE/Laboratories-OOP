package mirea;

public class Book implements Pricable
{
    private int price;
    private String author, name;
    Book(int _price, String _author, String _name){
        price = _price;
        author = _author;
        name = _name;
    }
    public void getPrice(){
        System.out.printf("Назание книги: %s\nЦена: %s рублей.\n", name, price);
    }
}
