package mirea;

public class Main
{
    public static void main(String[] args){
        Car Mercedes = new Car(12, 200, "Benz");
        Mercedes.getPrice();
        Book Faust = new Book(200, "Гете", "Фауст");
        Faust.getPrice();
    }
}
