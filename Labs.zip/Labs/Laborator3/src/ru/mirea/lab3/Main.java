package ru.mirea.lab3;

public class Main
{
    public static void main(String[] Args)
    {
        Chihuahua Sam = new Chihuahua(0.2, 4, "black");
        Retriever Becky = new Retriever(0.9, 12, "golden");
        Shepherd Danny = new Shepherd (1.2, 14, "brown");
        System.out.println("Chihuahua says " + Sam.bark());
        System.out.println("Shepherd says " + Danny.bark());
        System.out.println("Retriever says " + Becky.bark());
    }
}
