package ru.mirea.lab3;

public abstract class Dog
{
    Dog(double _height, double _weight, String _furColour){
        height = _height;
        weight = _weight;
        furColour = _furColour;
    }
    private double height, weight;
    private String furColour;
    public abstract String bark();
}

class Retriever extends Dog
{
    Retriever(double _height, double _weight, String _furColour)
    {
        super(_height, _weight, _furColour);
    }

    public String bark()
    {
        return "Woof";
    }

}

class Chihuahua extends Dog
{
    Chihuahua(double _height, double _weight, String _furColour)
    {
        super(_height, _weight, _furColour);
    }

    public String bark()
    {
        return "Wheeze";
    }
}

class Shepherd extends Dog
{
    Shepherd(double _height, double _weight, String _furColour)
    {
        super(_height, _weight, _furColour);
    }

    public String bark()
    {
        return "Bark";
    }
}
