package ru.mirea.lab5;
import java.util.Timer;
import java.awt.*;
import java.awt.event.*;
import java.util.TimerTask;
import javax.swing.*;

class lab5 extends JFrame
{
    private static boolean movement = false;
    public Timer timer = new Timer();
    public lab5()
    {
        JPanel pnl[] = new JPanel[2];
        JLabel lbl = new JLabel("");
        JButton bttn = new JButton("Press for animation");
        ImageIcon img[] = new ImageIcon[6];
        img[0] = new ImageIcon("no1.jpg");
        img[1] = new ImageIcon("no2.jpg");
        img[2] = new ImageIcon("no3.jpg");
        img[3] = new ImageIcon("no4.jpg");
        img[4] = new ImageIcon("no5.jpg");
        img[5] = new ImageIcon("no6.jpg");
        lbl.setIcon(img[0]);
        setLayout(new GridLayout(2,1));
        for (int i = 0; i < pnl.length; i++)
        {
            pnl[i] = new JPanel();
            add(pnl[i]);
        }
        pnl[0].add(bttn, BorderLayout.CENTER);
        pnl[1].add(lbl, BorderLayout.CENTER);
        setSize(300, 500);
        final TimerTask task = new TimerTask()
        {
            int index = 1;
            @Override
            public void run()
            {
                if(movement)
                {
                    lbl.setIcon(img[index]);
                    index++;
                    if (index == 6){index = 0;}
                }
                else
                {
                    timer.cancel();
                }
            }
        };
        bttn.addActionListener(e ->
        {
            movement = !movement;
            timer = new Timer();
            timer.scheduleAtFixedRate(task, 0, 200);
        });
    }

}

public class mainForm
{
    public static void main(String[] args)
    {
        new lab5().setVisible(true);
    }
}
